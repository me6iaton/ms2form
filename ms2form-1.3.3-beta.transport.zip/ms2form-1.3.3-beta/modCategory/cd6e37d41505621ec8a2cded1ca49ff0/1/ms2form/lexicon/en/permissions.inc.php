<?php
/**
 * Permissions Russian Lexicon Entries for ms2form
 *
 * @package ms2form
 * @subpackage lexicon
 */
$_lang['mscategory_save'] = 'Разрешает создание\изменение категории магазина';
$_lang['msproduct_save'] = 'Разрешает создание\изменение товара магазина';
$_lang['msproductfile_save'] = 'Разрешает создание\изменение файлов товара';
$_lang['msproductfile_generate'] = 'Разрешает генерацию превью картинок товара';
$_lang['msproductfile_list'] = 'Разрешает вывод списка файлов товара.';
$_lang['publish_document'] = 'Разрешает публикацию ресурса.';