--------------------
ms2form
--------------------
Author: Anton Mamrashev <me6iaton@gmail.com>
--------------------

Выводит форму для создания и редактирования продукта minishop2 пользователем из фронтэнда.

Donation
http://yasobe.ru/na/ms2form

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/me6iaton/ms2form/issues